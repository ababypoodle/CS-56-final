import java.io.*;
import java.net.*;
import java.util.*;

public class ContactClient {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    private static ObjectInputStream input;
    private static ObjectOutputStream output;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT)) {
            input = new ObjectInputStream(socket.getInputStream());
            output = new ObjectOutputStream(socket.getOutputStream());

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("Enter command (ADD/SEARCH/EXIT): ");
                String command = scanner.nextLine().toUpperCase();

                if (command.equals("EXIT")) {
                    break;
                } else if (command.equals("ADD")) {
                    System.out.println("Enter contact name: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter contact phone: ");
                    String phone = scanner.nextLine();
                    System.out.println("Enter contact email: ");
                    String email = scanner.nextLine();

                    Contact contact = new Contact(name, phone, email);
                    output.writeObject("ADD");
                    output.writeObject(contact);

                    String response = (String) input.readObject();
                    System.out.println(response);
                } else if (command.equals("SEARCH")) {
                    System.out.println("Enter search name: ");
                    String name = scanner.nextLine();

                    output.writeObject("SEARCH");
                    output.writeObject(name);

                    Object obj = input.readObject();
                    if (obj instanceof List<?>) {
                        @SuppressWarnings("unchecked")  // Suppress the warning for the cast
                        List<Contact> results = (List<Contact>) obj;
                        if (results.isEmpty()) {
                            System.out.println("No contacts found.");
                        } else {
                            System.out.println("Search results:");
                            for (Contact contact : results) {
                                  System.out.println(contact);
                            }
                          }
                      } else {
                          System.out.println("Invalid data received.");
                      }
            }
          }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
