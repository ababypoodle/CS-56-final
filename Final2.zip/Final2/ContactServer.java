import java.io.*;
import java.net.*;
import java.util.*;

public class ContactServer {
  
  private static List<Contact> contactList = new ArrayList<>();

	public static void main(String[] args) {
		
		try (ServerSocket serverSocket = new ServerSocket(8080)) {
			
			System.out.println("server started, waiting for connection...");
			Socket socket = serverSocket.accept();
			
			// in & out
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			
			System.out.println("connection established, listening...");
			
		 while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;
        private ObjectInputStream input;
        private ObjectOutputStream output;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                input = new ObjectInputStream(socket.getInputStream());
                output = new ObjectOutputStream(socket.getOutputStream());

                String command;
                while ((command = (String) input.readObject()) != null) {
                    if (command.equals("ADD")) {
                        Contact contact = (Contact) input.readObject();
                        contactList.add(contact);
                        output.writeObject("Contact added successfully.");
                    } else if (command.equals("SEARCH")) {
                        String name = (String) input.readObject();
                        List<Contact> results = searchContacts(name);
                        output.writeObject(results);
                    } else {
                        output.writeObject("Invalid command.");
                    }
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private List<Contact> searchContacts(String name) {
            List<Contact> results = new ArrayList<>();
            for (Contact contact : contactList) {
                if (contact.getName().toLowerCase().contains(name.toLowerCase())) {
                    results.add(contact);
                }
            }
            return results;
        }
    }
}

