import java.io.*;
import java.net.*;
import java.util.*;

public class ContactClient {

	public static void main(String[] args) {
		
		try (Socket socket = new Socket("localhost", 8080);
			Scanner scanner = new Scanner(System.in)) {
			
			// in & out 
			//BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			//PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
			
			ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
      ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
			
			do {
                System.out.println("Enter command (ADD/SEARCH/EXIT): ");
                String command = scanner.nextLine().toUpperCase();

                if (command.equals("EXIT")) {
                    break;
                } else if (command.equals("ADD")) {
                    System.out.println("Enter contact name: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter contact phone: ");
                    String phone = scanner.nextLine();
                    System.out.println("Enter contact email: ");
                    String email = scanner.nextLine();

                    Contact contact = new Contact(name, phone, email);
                    output.writeObject("ADD");
                    output.writeObject(contact);

                    String response = (String) input.readObject();
                    System.out.println(response);
                } else if (command.equals("SEARCH")) {
                    System.out.println("Enter search name: ");
                    String name = scanner.nextLine();

                    output.writeObject("SEARCH");
                    output.writeObject(name);

                    Object obj = input.readObject();
                    if (obj instanceof List<?>) {
                        @SuppressWarnings("unchecked")  // Suppress the warning for the cast
                        List<Contact> results = (List<Contact>) obj;
                        if (results.isEmpty()) {
                            System.out.println("No contacts found.");
                        } else {
                            System.out.println("Search results:");
                            for (Contact contact : results) {
                                  System.out.println(contact);
                            }
                          }
                      } else {
                          System.out.println("Invalid data received.");
                      }
            }
          } while(true);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
